import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Page1 extends StatefulWidget {
  const Page1({super.key});

  @override
  State<Page1> createState() => _Page1State();
}

class _Page1State extends State<Page1> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController weightController = TextEditingController();
  final TextEditingController heightController = TextEditingController();

  final CollectionReference bmiCollection =
      FirebaseFirestore.instance.collection('bmi_data');

  String? selectedId;

  double calculateBMI(double weight, double heightCm) {
    double heightM = heightCm / 100;
    return weight / (heightM * heightM);
  }

  void addOrUpdate() {
    String name = nameController.text;
    double weight = double.parse(weightController.text);
    double height = double.parse(heightController.text);

    double bmi = calculateBMI(weight, height);

    Map<String, dynamic> data = {
      'name': name,
      'weight': weight,
      'height': height,
      'bmi': bmi.toStringAsFixed(2),
    };

    if (selectedId == null) {
      bmiCollection.add(data);
    } else {
      bmiCollection.doc(selectedId).update(data);
      selectedId = null;
    }

    nameController.clear();
    weightController.clear();
    heightController.clear();
  }

  void deleteData(String id) {
    bmiCollection.doc(id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("BMI Calculator - Firebase")),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: "Name",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: weightController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Weight (kg)",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: heightController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Height (cm)",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: addOrUpdate,
                child: Text(selectedId == null ? "Calculate & Save" : "Update"),
              ),
            ),
            const SizedBox(height: 20),

            Expanded(
              child: StreamBuilder(
                stream: bmiCollection.snapshots(),
                builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(
                        child: CircularProgressIndicator());
                  }

                  return ListView(
                    children: snapshot.data!.docs.map((doc) {
                      return Card(
                        child: ListTile(
                          title: Text(doc['name']),
                          subtitle: Text(
                              "Weight: ${doc['weight']} kg\nHeight: ${doc['height']} cm\nBMI: ${doc['bmi']}"),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit,
                                    color: Colors.orange),
                                onPressed: () {
                                  setState(() {
                                    nameController.text = doc['name'];
                                    weightController.text =
                                        doc['weight'].toString();
                                    heightController.text =
                                        doc['height'].toString();
                                    selectedId = doc.id;
                                  });
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete,
                                    color: Colors.red),
                                onPressed: () {
                                  deleteData(doc.id);
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}